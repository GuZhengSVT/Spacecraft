Project Apollo - NASSP contributors. GPL version 2.
Complete editable geometry, textures and license used for the two GLB conversions.
Upstream revision: 914090467d085946a95d911cbaca0804047d4665
Conversion source: https://github.com/GuZhengSVT/Spacecraft/blob/main/scripts/build-apollo.mjs
